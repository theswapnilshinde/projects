package com.tech.dynamic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DynamicApplicationTests {

	@Test
	void contextLoads() {
	}

}
